# Multiple-disease-prediction-using-different-machine-learning-algorithms
A multi-disease(test based) prediction system for diabetes , heart and parkinson disease patients. The major problem in all these diseases is their detection. Early detection of these diseases may lead to decrease in mortality rate and overall complications.
